//
//  ReviewView.swift
//  hw9
//
//  Created by Jonathan on 12/4/22.
//

import SwiftUI

struct ReviewView: View {
    @State var reviews: [Review]
    
    init(reviews_data: [Review]) {
        self.reviews = reviews_data
    }
    var body: some View {
        List{
            ForEach(reviews, id: \.self){ review in
                VStack{
                    HStack{
                        Text(review.name).bold()
                        Spacer()
                        Text(review.rating)
                    }.padding([.top, .leading, .trailing], 30)
                    HStack{
                        Text(review.review)
                    }.frame(maxWidth: .infinity, alignment: .leading)
                        .padding(30)
                        .foregroundColor(Color.gray)
                    HStack{
                        Text(review.time)
                    }
                }
            }
        }
    }
}

//struct ReviewView_Previews: PreviewProvider {
//    static var previews: some View {
//        //ReviewView(reviews_data: [Review])
//    }
//}
