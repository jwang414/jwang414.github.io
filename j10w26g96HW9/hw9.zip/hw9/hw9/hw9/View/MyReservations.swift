//
//  MyReservations.swift
//  hw9
//
//  Created by Jonathan on 12/7/22.
//

import SwiftUI

struct MyReservations: View {
    @EnvironmentObject var currReservation: ReservationModel
    
    var body: some View {
        
        NavigationView {
            if currReservation.myReservation.count == 0 {
                VStack{
                    Text("No bookings found")
                        .foregroundColor(Color.red)
                }.background(Color.white)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .principal) {
                            VStack {
                                Text("Your Reservation").font(.headline)
                            }
                        }
                    }
            }
            else{
                List{
                    ForEach(currReservation.myReservation, id: \.self) { res in
                        HStack(spacing: 0){
                            Spacer()
                            Text(res.name)
                                .minimumScaleFactor(0.001)
                                .lineLimit(2)
                            Spacer()
                            Text(res.date)
                                .minimumScaleFactor(0.2)
                                .lineLimit(1)
                            Spacer()
                            Text(res.time)
                                .minimumScaleFactor(0.2)
                                .lineLimit(1)
                            Spacer()
                            Text(res.email)
                                .minimumScaleFactor(0.2)
                                .lineLimit(1)
                                .foregroundColor(Color.black)
                            Spacer()
                        }
                        .padding(0)
                    }.onDelete { indexSet in
                        currReservation.myReservation.remove(atOffsets: indexSet)
                      }
                }
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .principal) {
                        VStack {
                            Text("Your Reservation").font(.headline)
                        }
                    }
                }
            }
        }
    }
}

struct MyReservations_Previews: PreviewProvider {
    static var previews: some View {
        MyReservations().environmentObject(ReservationModel())
    }
}
