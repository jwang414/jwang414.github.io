//
//  TabView.swift
//  hw9
//
//  Created by Jonathan on 12/5/22.
//

import SwiftUI

struct TabView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct TabView_Previews: PreviewProvider {
    static var previews: some View {
        TabView()
    }
}
