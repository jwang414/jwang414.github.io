//
//  SplashScreen.swift
//  hw9
//
//  Created by Jonathan on 12/7/22.
//

import SwiftUI

struct SplashScreen: View {
    @State var isOn : Bool = false
    @State private var size = 0.75
    //@State private var opacity = 0.4
    
    var body: some View {
        if isOn {
            ContentView()
        } else {
            VStack {
                VStack {
                    Image("launchScreenImage")
                        .foregroundColor(.red)
                }
                .scaleEffect(size)
                //.opacity(opacity)
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.98) {
                    withAnimation {
                        self.isOn = true
                    }
                }
            }
        }
    }
}
struct SplashScreen_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreen()
    }
}
