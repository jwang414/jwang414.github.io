//
//  DetailsView.swift
//  hw9
//
//  Created by Jonathan on 12/4/22.
//

import SwiftUI
import Combine
import SimpleToast

struct DetailsView: View {
    @State var businessDetails: BusinessDetails
    @State private var showSheet = false
    @EnvironmentObject var currReservation: ReservationModel
    
    @State var showToast = false
    
    private var toastOptionsInvalid = SimpleToastOptions(
        alignment: .bottom,
        hideAfter: 5,
        animation: .default,
        modifierType: .slide
    )
    
    init(businessDetail_data: BusinessDetails) {
        self.businessDetails = businessDetail_data
    }
    var body: some View {
        VStack{
            Text(businessDetails.name)
                .bold()
                .font(.system(size: 25))
            HStack{
                VStack{
                    Text("Address")
                        .bold()
                    Text(businessDetails.location)
                }
                .padding()
                Spacer()
                VStack{
                    Text("Category")
                        .bold()
                    Text(businessDetails.category)
                }
                .padding()
            }
            
            HStack{
                VStack{
                    Text("Phone")
                        .bold()
                    Text(businessDetails.phone)
                }
                .padding()
                Spacer()
                VStack{
                    Text("Price Range")
                        .bold()
                    Text(businessDetails.price)
                }
                .padding()
            }
            HStack{
                VStack{
                    Text("Status")
                        .bold()
                    Text(businessDetails.status)
                        .foregroundColor(isOpenStatus(status: businessDetails.status))
                }
                .padding()
                Spacer()
                VStack{
                    Text("Visit Yelp for more")
                        .bold()
                    
                    Link("Business Link", destination: URL(string: businessDetails.url) ?? URL(string: "https://google.com")!)
                }
                .padding()
            }
            HStack{
                if currReservation.containsReservation(bus_name: businessDetails.name){
                    Button(action: {
                        currReservation.removReservation(bus_name: businessDetails.name)
                        showToast = true
                    }) {
                        Text("Cancel Reservation")
                            .frame(width: 250 , height: 50, alignment: .center)
                            .bold()
                        
                            
                    }
                     .background(Color.blue)
                     .foregroundColor(Color.white)
                     .cornerRadius(15)
                }
                else{
                    Button(action: {
                        showSheet = true
                    }) {
                        Text("Reserve Now")
                            .frame(width: 135 , height: 50, alignment: .center)
                            .bold()
                    }
                     .background(Color.red)
                     .foregroundColor(Color.white)
                     .cornerRadius(15)
                     .sheet(isPresented: $showSheet, content: {
                         ReservationSheetView(bus_name: businessDetails.name)
                            })
                }
            }
            
            HStack{
                Text("Share on: ")
                    .bold()
                Link(destination: URL(string: "https://www.facebook.com/sharer/sharer.php?u=\(businessDetails.url)") ?? URL(string: "https://google.com")!) {
                    Image("fb")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50)
                }
                
                Link(destination: URL(string: "https://twitter.com/intent/tweet?text=Check%20\(businessDetails.name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)!)%20on%20Yelp!&url=\(businessDetails.url)") ?? URL(string: "https://google.com")!) {
                    Image("twit")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50)
                }
            }
            HStack{
                CarouselView(image_list: businessDetails.image)
            }
            Spacer()
        }.simpleToast(isPresented: $showToast, options: toastOptionsInvalid){
            HStack{
                Text("Your Reservation is canceled.")
            }
            .padding(30)
            .background(Color.gray.opacity(0.8))
            .foregroundColor(Color.white)
            .cornerRadius(14)
            
        }
        
    }
}

func isOpenStatus(status: String)-> Color{
    if status == "Open Now"{
        return Color.green
    }
    return Color.red
}

//struct DetailsView_Previews: PreviewProvider {
//    static var previews: some View {
//        DetailsView(businessDetail_data: BusinessDetails)
//    }
//}
