//
//  ReservationSheetView.swift
//  hw9
//
//  Created by Jonathan on 12/6/22.
//

import SwiftUI
import SimpleToast

struct ReservationSheetView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var currReservation: ReservationModel
    
    @State var email = ""
    @State var date = Date()
    @State var time_hour = "10"
    @State var time_min = "00"
    @State var showToastInvalid = false
    @State var showToastSucess = false
    
    var name: String
    
    init(bus_name: String){
        self.name = bus_name
    }
    
    
    private var toastOptionsInvalid = SimpleToastOptions(
        alignment: .bottom,
        hideAfter: 5,
        animation: .default,
        modifierType: .slide
        
        
    )
    private let toastOptionsValid = SimpleToastOptions(
        alignment: .center,
        hideAfter: 15,
        backdrop: Color.green,
        animation: .default,
        modifierType: .slide
        
    )
    let min_picker = ["00","15","30","45"]
    let hour_picker = ["10","11","12", "13","14","15","16","17"]
    let dateRange: ClosedRange<Date> = {
        let calendar = Calendar.current
        let startComponents = DateComponents(year: Calendar.current.component(.year, from: Date()), month: Calendar.current.component(.month, from: Date()), day: Calendar.current.component(.day, from: Date()))
        let endComponents = DateComponents(year: 3000, month: 12, day: 31, hour: 23, minute: 59, second: 59)
        return calendar.date(from:startComponents)!
        ...
        calendar.date(from:endComponents)!
    }()
    
    var body: some View {
        VStack {
            Spacer()
            HStack() {
                Text("Reservation Form")
            }.frame(minWidth: 350)
            .bold()
            .background(Color.white)
            .font(.system(size: 36))
            .cornerRadius(10)
            Spacer().frame(height: 50)
            HStack{
                Text(name)
                    .background(Color.white)
            }
            .frame(minWidth: 350)
            .bold()
            .background(Color.white)
            .font(.system(size: 36))
            .cornerRadius(10)
            Form{
                HStack{
                    Text("Email: ")
                        .frame(width: 50, alignment: .leading)
                        .foregroundColor(Color.gray)
                    TextField("", text: $email)
                }
                HStack{
                    HStack(spacing: 0){
                        Text("Date/Time: ")
                            .frame(width: 100, alignment: .leading)
                            .foregroundColor(Color.gray)
                        DatePicker(
                            "Start Date",
                            selection: $date,
                            in: dateRange,
                            displayedComponents: [.date]
                        ).labelsHidden()
                    }
                    HStack(spacing: 0){
                        //Spacer()
                        Picker("Hour", selection: $time_hour, content: {
                            ForEach(10..<18) { number in
                                Text("\(number)").tag("\(number)")
                            }
                        })
                        .frame(width: 10)
                        .padding(.leading, -1)
                        .pickerStyle(.menu)
                        .labelsHidden()
                       
                        Text(":")
                            .foregroundColor(Color.black)
                            .padding(.horizontal, 20.0)
                        
                        Picker("Min", selection: $time_min, content: {
                            ForEach(min_picker, id: \.self) { number in
                                Text("\(number)").tag("\(number)")
                            }
                        })
                        .padding(.leading, -18.0)
                        .frame(width: 10)
                        .pickerStyle(.menu)
                        .labelsHidden()
                        //Spacer()
                        
                    }.frame(width:95)
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                        
                }
                HStack{
                    Button("Submit") {
                        if (formValidate(strToValidate: email)){
                            showToastSucess = true
                        }
                        else{
                            showToastInvalid = true
                            email = ""
                        }
                    }
                    .frame(width: 65)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(Color.white)
                    .font(.headline)
                    .fontWeight(.semibold)
                    .cornerRadius(10)
                    
                }.frame(maxWidth: .infinity, alignment: .center)
            }
            
        }
        .background(Color(.systemGray6))
        .simpleToast(isPresented: $showToastInvalid, options: toastOptionsInvalid){
                HStack{
                    Text("Please enter a valid email.")
                }
                .padding(20)
                .background(Color.gray.opacity(0.8))
                .foregroundColor(Color.white)
                .cornerRadius(14)
                
        }
        .simpleToast(isPresented: $showToastSucess, options: toastOptionsValid){
            VStack {
                Spacer()
                HStack{
                    Text("Congratulations!")
                }
                .frame(width: 200)
                .padding(20)
                .foregroundColor(Color.white)
                .fontWeight(.semibold)
                
                Spacer().frame(height: 10)
                
                HStack{
                    Text("You have successfully made a reservation at \(name)")
                        .frame(width: 350)
                        .multilineTextAlignment(.center)
                }
                .frame(width: 200)
                .padding(20)
                .foregroundColor(Color.white)
                Spacer()
                HStack{
                    Button("Done") {
                        currReservation.appendReservation(res_input: createReservation(name_input: name, date_input: date, hour_input: time_hour, min_input: time_min, email_input: email))
                        print(currReservation)
                        //presentationMode.wrappedValue.dismiss()
                    }
                    .frame(width: 80)
                    .padding()
                    .background(Color.white)
                    .foregroundColor(Color.green)
                    //.font(.headline)
                    .fontWeight(.semibold)
                    .cornerRadius(30)
                }
            
            }
        }

    }
}
//validates email
func formValidate(strToValidate: String) -> Bool {
  let emailValidationRegex = "^[\\p{L}0-9!#$%&'*+\\/=?^_`{|}~-][\\p{L}0-9.!#$%&'*+\\/=?^_`{|}~-]{0,63}@[\\p{L}0-9-]+(?:\\.[\\p{L}0-9-]{2,7})*$"  // 1

  let emailValidationPredicate = NSPredicate(format: "SELF MATCHES %@", emailValidationRegex)  // 2

  return emailValidationPredicate.evaluate(with: strToValidate)  // 3
}

func createReservation(name_input:String, date_input: Date, hour_input: String, min_input: String, email_input: String) -> Reservation {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "YY-MM-dd"
    dateFormatter.string(from: date_input)
    
    let time = "\(String(hour_input)) : \(String(min_input))"
    
    let reservation = Reservation(name: name_input, date: dateFormatter.string(from: date_input), time: time, email: email_input)
    
    return reservation
}



struct ReservationSheetView_Previews: PreviewProvider {
    static var previews: some View {
        ReservationSheetView(bus_name: "Dunkin Donuts").environmentObject(ReservationModel())
    }
}


/**/
