//
//  ContentView.swift
//  hw9
//
//  Created by Jonathan on 12/2/22.
//

import SwiftUI
import CoreLocation
import CoreLocationUI
import Combine

struct ContentView: View {
    @State public var keyword = ""
    @State public var distance = "10"
    @State public var category = "All"
    @State public var location = ""
    @State public var autoLocation = false
    @StateObject var deviceLocationService = DeviceLocationService.shared
    @State private var fetched = false
    @State var business_URL_INPUT = ""
    
    @State var tokens: Set<AnyCancellable> = []
    @State var lat: Double = 0.0
    @State var long: Double = 0.0
    
    @StateObject var myReservations = ReservationModel()
    @StateObject var businessModel = BusinessModel()
    
    var body: some View {
        NavigationView {
            
            ZStack {
                VStack (spacing: 0) {
                    Form{
                        HStack {
                            Text("Keyword:").frame(width: 100, alignment: .leading)
                            TextField("Required", text: $keyword)
                        }
                        HStack {
                            Text("Distance:").frame(width: 100, alignment: .leading)
                            TextField("Required", text: $distance)
                        }
                        HStack {
                            Text("Category:").frame(width: 90, alignment: .leading)
                            Picker("Category:", selection: $category) {
                                Text("Default").tag("All")
                                Text("Arts and Entertainment").tag("arts")
                                Text("Health and Medical").tag("health")
                                Text("Hotels and Travel").tag("travel")
                                Text("Food").tag("food")
                                Text("Professional Services").tag("professional")
                            }
                            .pickerStyle(.menu)
                            .labelsHidden()
                            
                            
                        }
                        if autoLocation == false {
                            HStack() {
                                Text("Location:").frame(width: 100, alignment: .leading)
                                TextField("Required", text: $location)
                            }
                        }
                        HStack {
                            Text("Auto-detect my location").frame(width: 200, alignment: .leading)
                            Toggle(isOn: $autoLocation.animation()) {
                            }.onChange(of: autoLocation) {
                                value in
                                observeCoordinateUpdates()
                                observeDeniedLocationAccess()
                                deviceLocationService.requestLocationUpdates()
                            }
                            
                        }
                        HStack(spacing: 40){
                            Button("Submit") {
                                if !autoLocation{
                                    getGoogleCoordinates(keyword: keyword, distance: distance, category: category, location: location, autolocation: autoLocation)
                                }
                                else{
                                    submitForm(keyword: keyword, distance: distance, category: category, location: location, autolocation: autoLocation, lat: lat, long: long)
                                }
                                businessModel.fetch = false
                                
                            }
                            .buttonStyle(BorderlessButtonStyle())
                            .frame(width: 75)
                            .padding()
                            .background(disabledColor)
                            .foregroundColor(Color.white)
                            .font(.headline)
                            .fontWeight(.semibold)
                            .cornerRadius(10)
                            .disabled(formValidate)
                            
                            Button("Clear") {
                                keyword = ""
                                distance = "10"
                                category = "All"
                                location = ""
                                autoLocation = false
                                fetched = false
                                business_URL_INPUT = ""
                                businessModel.fetch = false
                            }
                            .buttonStyle(BorderlessButtonStyle())
                            .frame(width: 75)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(Color.white)
                            .font(.headline)
                            .fontWeight(.semibold)
                            .cornerRadius(10)
                            
                            
                        }.frame(maxWidth: .infinity, alignment: .center)
                            .navigationTitle("Business Search")
                            .toolbar{
                                ToolbarItemGroup(placement: .navigationBarTrailing){
                                    NavigationLink(destination: MyReservations()){
                                        Label("reservations", systemImage: "calendar.badge.clock")
                                    }
                                }
                                    
                            }
                        Section{
                            if fetched == true{
                                ResultsListView(business_URL_INPUT: business_URL_INPUT)
                            }
                            else{
                                List{
                                    Text("Results")
                                        .bold()
                                        .font(.system(size: 25))
                                }
                            }
                        }
                    }
                }
            }
        }
        .environmentObject(myReservations)
        .environmentObject(businessModel)
        
    }
    
    func getGoogleCoordinates (keyword: String, distance: String, category: String, location: String, autolocation: Bool) {
        let group = DispatchGroup()
        group.enter()
        Task {
            do{
                try await googleCoordinates(location: location)
            }
            catch{
                print("Error google coordinates")
            }
            group.leave()
        }
        group.notify(queue: .main) {
            submitForm(keyword: keyword, distance: distance, category: category, location: location, autolocation: autoLocation, lat: lat, long: long)
        }
        
    }
    
    func submitForm(keyword: String, distance: String, category: String, location: String, autolocation: Bool, lat: Double, long: Double) {
        var parameters = Dictionary<String, Any>()
        
        if keyword.last == " " {
            parameters["terms"] = String(keyword.dropLast())
        }
        else{
            parameters["terms"] = keyword
        }
        parameters["radius"] = (Double(distance)!*1609.344)
        parameters["category"] = category
        parameters["lat"] = lat
        parameters["long"] = long
        
        let business_API = "https://homework8-try-server.wm.r.appspot.com/search?&terms=\(parameters["terms"] ?? "")&radius=\(parameters["radius"] ?? "")&category=\(parameters["category"] ?? "")&latitude=\(parameters["lat"] ?? "")&longitude=\(parameters["long"] ?? "")"
        DispatchQueue.main.async {
            self.business_URL_INPUT = business_API
            self.fetched = true
        }
        
    }
    
    
    var formValidate: Bool{
        return distance.count == 0 || keyword.count == 0 || (location.count == 0 && autoLocation == false)
    }
    var disabledColor: Color{
        return !formValidate ? Color.red : Color.gray
    }
    //helper cooordinates
    func observeCoordinateUpdates() {
        deviceLocationService.coordinatesPublisher
            .receive(on: DispatchQueue.main)
            .sink { completion in
                print("Handle \(completion) for error and finished subscription.")
            } receiveValue: { coordinates in
                self.lat = coordinates.latitude
                self.long = coordinates.longitude
            }
            .store(in: &tokens)
    }

    func observeDeniedLocationAccess() {
        deviceLocationService.deniedLocationAccessPublisher
            .receive(on: DispatchQueue.main)
            .sink {
                print("Handle access denied event, possibly with an alert.")
            }
            .store(in: &tokens)
    }
    func googleCoordinates(location: String) async throws{
        
        let url_base = "https://homework8-try-server.wm.r.appspot.com/search/googleLocation/"
        var temp_loc_keyword = location.replacingOccurrences(of: " ", with: "+")
        temp_loc_keyword = temp_loc_keyword.replacingOccurrences(of: ",", with: "+")
        if temp_loc_keyword.last == "+"{
            temp_loc_keyword = String(temp_loc_keyword.dropLast())
        }
        let url = URL(string: url_base + temp_loc_keyword)
        guard let requestUrl = url else { fatalError("Missing URL") }
        // Create URL Request
        var request = URLRequest(url: requestUrl)
        // Specify HTTP Method to use
        request.httpMethod = "GET"
        // Send HTTP Request
        let (data, response) = try await URLSession.shared.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { fatalError("Error while fetching data") }
        let coord = try JSONSerialization.jsonObject(with: data, options: []) as! [String]
        self.lat = Double(coord[0])!
        self.long = Double(coord[1])!
    }
    //let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String]
    
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
            ContentView()
    }
}

