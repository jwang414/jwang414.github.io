//
//  CarouselView.swift
//  hw9
//
//  Created by Jonathan on 12/4/22.
//

import SwiftUI

struct CarouselView: View {
    var image_list: [String]
    var body: some View {
        VStack{
            TabView{
                ForEach(image_list, id: \.self){ image in
                    SingleItemView(image_url: image)
                        .padding()
                }
            }.tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
        }
    }
}


struct SingleItemView: View{
    var image_url: String
    
    var body: some View {
        AsyncImage(url: URL(string: image_url)) { image in
            image
                .resizable()
                .frame(width: 330, height: 330)
        } placeholder: {
            ProgressView()
        }
    }
}

struct CarouselView_Previews: PreviewProvider {
    static var previews: some View {
        CarouselView(image_list: ["https://s3-media2.fl.yelpcdn.com/bphoto/M56OBYKzI5tvQoAoCBTYhg/o.jpg","https://s3-media4.fl.yelpcdn.com/bphoto/Jabf8aDig5ndpWSZqg9oNA/o.jpg","https://s3-media2.fl.yelpcdn.com/bphoto/lYQ8pcBRfmrKeF8uGPgtBg/o.jpg"])
    }
}
