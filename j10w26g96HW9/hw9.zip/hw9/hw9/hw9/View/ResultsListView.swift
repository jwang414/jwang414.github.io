//
//  ResultsListView.swift
//  hw9
//
//  Created by Jonathan on 12/6/22.
//

import SwiftUI
import CoreLocation
import CoreLocationUI
import Combine

struct ResultsListView: View {
    @EnvironmentObject var businessModel : BusinessModel
    
    
    var bus_URL_API: String
    init(business_URL_INPUT: String){
        self.bus_URL_API = business_URL_INPUT
    }
    var body: some View {
        List{
            Text("Results")
                .bold()
                .font(.system(size: 25))
            if businessModel.fetch == false {
                HStack{
                    Spacer()
                    ProgressView("Please Wait...")
                        .onAppear(perform: {
                            businessModel.fetchSearchData(url_input: self.bus_URL_API, completion: {
                                businessModel.businesses = Array(businessModel.businesses.prefix(10))
                            })
                        })
                    Spacer()
                }
            }
            else if businessModel.businesses.count == 0{
                Text("No results avaliable").foregroundColor(Color.red)
            }
            else{
                ForEach(businessModel.businesses.enumeratedArray(), id: \.element){ index, business in
                    NavigationLink(destination: DetailNavigationView(business_ID: business.id)) {
                        Text("\(index+1)").frame(width: 25)
                        AsyncImage(url: URL(string: business.image_url)){ image in
                            image.resizable()
                        } placeholder: {
                            ProgressView()
                        }
                        .frame(width: 50, height: 50)
                        Text(business.name)
                            .frame(width: 150, height: 65)
                            .font(.system(size: 15))
                            .foregroundColor(Color.gray)
                        Text(business.rating)
                            .frame(width: 30)
                            .bold()
                        
                        Text(business.distance)
                            .frame(width: 25)
                            .bold()
                    }
                }
            }
        }
    }
}

struct ResultsListView_Previews: PreviewProvider {
    static var previews: some View {
        ResultsListView(business_URL_INPUT: "https://homework8-try-server.wm.r.appspot.com/search?&terms=food&radius=16093.44&category=All&latitude=34.0522342&longitude=-118.2436849")
    }
}
