//
//  DetailNavigationView.swift
//  hw9
//
//  Created by Jonathan on 12/5/22.
//

import SwiftUI

struct DetailNavigationView: View {
    @StateObject var businessDetails = BusinessDetailModel()
    @State var fetched_data = false
    var bus_ID: String
    
    init(business_ID: String) {
        self.bus_ID = business_ID
    }
    var body: some View {
        TabView{
            if fetched_data == true{
                DetailsView(businessDetail_data: businessDetails.businessesDetails)
                .tabItem{
                    Image(systemName: "text.bubble.fill")
                    Text("Business Details")
                }.tag(1)
                MapView(name: businessDetails.businessesDetails.name, lat: businessDetails.businessesDetails.coordinates[0], long: businessDetails.businessesDetails.coordinates[1]).tabItem{
                    Image(systemName: "location.fill")
                    Text("Map Location")
                }.tag(2)
                ReviewView(reviews_data: businessDetails.businessesDetails.all_reviews).tabItem{
                    Image(systemName: "message.fill")
                    Text("Reviews")
                }.tag(3)
            }
        }.onAppear{
            businessDetails.fetchSearchData(url_input: "https://homework8-try-server.wm.r.appspot.com/search/details/\(self.bus_ID)", completion: {
                fetched_data = businessDetails.fetch
                
            })
        }
    }
}


//struct DetailNavigationView_Previews: PreviewProvider {
//    static var previews: some View {
//        DetailNavigationView()
//    }
//}
