//
//  MapView.swift
//  hw9
//
//  Created by Jonathan on 12/4/22.
//

import SwiftUI
import MapKit

struct MapView: View {
    @State var region: MKCoordinateRegion
    @State var lat: Double
    @State var long: Double
    @State var pin: [Location]
    init(name: String, lat: Double, long: Double){
        self.region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: lat,
                                               longitude: long),
                latitudinalMeters: 750,
                longitudinalMeters: 750
            )
        self.lat = lat
        self.long = long
        self.pin = [Location(name: name, coordinate: CLLocationCoordinate2D(latitude: lat,longitude: long))]
    }

        var body: some View {
            Map(coordinateRegion: $region, annotationItems: pin){ location in
                MapMarker(coordinate: location.coordinate)
            }.ignoresSafeArea(.container, edges: .top)
        }
}
struct Location: Identifiable {
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView(name: "dropped location", lat: 34.050052, long: -118.242365551451)
    }
}
