//
//  BusinessModel.swift
//  homework9
//
//  Created by Jonathan on 11/23/22.
//

import Foundation
import SwiftUI
import Alamofire
import SwiftyJSON

protocol JSONable {
    init?(parameter: JSON)
}

struct Reservation: Codable, Hashable{
    let name: String
    let date: String
    let time: String
    let email: String
}

struct Business: Codable, Hashable, JSONable, Identifiable{
    let name: String
    let url: String
    let image_url: String
    let rating: String
    let distance: String
    let id: String
    init(parameter: JSON) {
        name = parameter["name"].stringValue
        url = parameter["url"].stringValue
        image_url = parameter["image_url"].stringValue
        rating = parameter["rating"].stringValue
        distance = parameter["distance"].stringValue
        id = parameter["id"].stringValue
    }
    
}
struct Review: Codable, Hashable, JSONable {
    let name: String
    let review: String
    let time: String
    let rating: String
    init(parameter: JSON) {
        name = parameter["name"].stringValue
        review = parameter["review"].stringValue
        time = parameter["time"].stringValue
        rating = parameter["rating"].stringValue
    }
}

struct BusinessDetails: Codable, Hashable, JSONable {
    let status: String
    let location: String
    let name: String
    let price: String
    let phone: String
    let category: String
    let transactions: String
    let image: [String]
    let url: String
    let coordinates: [Double]
    let all_reviews: [Review]
    init(parameter: JSON) {
        status = parameter["status"].stringValue
        location = parameter["location"].stringValue
        name = parameter["name"].stringValue
        price = parameter["price"].stringValue
        phone = parameter["phone"].stringValue
        category = parameter["category"].stringValue
        transactions = parameter["transactions"].stringValue
        image = parameter["image"].arrayValue.map { $0.stringValue}
        url = parameter["url"].stringValue
        coordinates = parameter["coordinates"].arrayValue.map { $0.doubleValue}
        all_reviews = parameter["all_reviews"].arrayValue.map {Review(parameter: $0)}
    }
}

class ReservationModel: ObservableObject{
    @Published var myReservation: [Reservation] = []
    
    func appendReservation(res_input: Reservation){
        
        if self.myReservation.contains(res_input){
            self.myReservation.find_and_remove(object: res_input)
        }
        self.myReservation.append(res_input)

    }
    func removReservation(bus_name: String){
        for (index, element) in myReservation.enumerated(){
            if element.name == bus_name{
                self.myReservation.remove(at: index)
            }
        }
    }
    func containsReservation(bus_name: String) ->Bool{
        for item in myReservation{
            if item.name == bus_name{
                return true
            }
        }
        return false
    }
    
}
class BusinessDetailModel: ObservableObject {
    @Published var businessesDetails : BusinessDetails = BusinessDetails(parameter: "")
    @Published var hasResults: Bool = false
    @Published var fetch: Bool = false
    func fetchSearchData(url_input: String, completion : @escaping  ()->()) {
        businessesDetails = BusinessDetails(parameter: "")
        AF.request(url_input).responseData { response in
            if response.data != nil {
                let json = try! JSON(data: response.data!)
                if(json != JSON.null) {
                    let temp_parse =  self.parseObj(json)
                    DispatchQueue.main.async {
                        self.businessesDetails = temp_parse
                        //self.hasData = (self.businessesDetails.count == 0)
                        self.fetch = true
                        completion()
                    }
                }
            }
        }
    }
    private func parseObj(_ results: JSON) -> BusinessDetails {
        var data: BusinessDetails = BusinessDetails(parameter: "")
        if let info_details = results.to(type: BusinessDetails.self) {
            data = info_details as! BusinessDetails
        }
        return data
    }
    func resetInfo(){
        self.businessesDetails = BusinessDetails(parameter: "")
        self.fetch = false
        self.hasResults = false
    }
    
}


class BusinessModel: ObservableObject {
    @Published var businesses: [Business] = []
    @Published var hasResults: Bool = false
    @Published var fetch: Bool = false
    func fetchSearchData(url_input: String, completion: @escaping  ()->()) {
        AF.request(url_input).responseData { response in
            if response.data != nil {
                let json = try! JSON(data: response.data!)
                if(json != JSON.null) {
                    let temp_parse =  self.parseSearchItems(json)
                    DispatchQueue.main.async {
                        self.businesses = temp_parse
                        self.hasResults = (self.businesses.count == 0)
                        self.fetch = true
//                        print(self.businesses)
                        completion()
                    }
                }
            }
        }
    }
    
    func resetInfo(){
        self.businesses = []
        self.fetch = false
        self.hasResults = false
    }
    private func parseSearchItems(_ results: JSON) -> [Business] {
        var info:[Business] = []
        if let info_details = results.to(type: Business.self) {
            info = info_details as! [Business]
        }
        return info
    }
    
}




