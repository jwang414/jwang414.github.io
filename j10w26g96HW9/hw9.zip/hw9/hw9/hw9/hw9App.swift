//
//  hw9App.swift
//  hw9
//
//  Created by Jonathan on 12/2/22.
//

import SwiftUI

@main
struct hw9App: App {
    var body: some Scene {
        WindowGroup {
            SplashScreen()
        }
    }
}
