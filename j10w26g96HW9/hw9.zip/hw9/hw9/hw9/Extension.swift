//
//  Extension.swift
//  hw9
//
//  Created by Jonathan on 12/2/22.
//

import Foundation
import SwiftyJSON

//stackoverflow for fixing parsing JSON arrays inside JSON objects
extension JSON {
    func to<T>(type: T?) -> Any? {
        if let baseObj = type as? JSONable.Type {
            if self.type == .array {
                var arrObject: [Any] = []
                for obj in self.arrayValue {
                    let object = baseObj.init(parameter: obj)
                    arrObject.append(object!)
                }
                return arrObject
            } else {
                let object = baseObj.init(parameter: self)
                return object!
            }
        }
        return nil
    }
}
//stackoverflow for enumerating collection
extension Collection {
  func enumeratedArray() -> Array<(offset: Int, element: Self.Element)> {
    return Array(self.enumerated())
  }
}
//stackoverflow for finding and removing array object
extension Array where Element: Equatable {

    // Remove first collection element that is equal to the given `object`:
    mutating func find_and_remove(object: Element) {
        guard let index = firstIndex(of: object) else {return}
        remove(at: index)
    }

}
